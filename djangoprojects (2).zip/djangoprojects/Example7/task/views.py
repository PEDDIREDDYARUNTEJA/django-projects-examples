from django.shortcuts import render

# Create your views here.
def data(req):
    data={'sid':101,'sname':'arun','marks':[90,95,80],'result':'Pass'}
    return render(req,'datadisplay.html',data)
    