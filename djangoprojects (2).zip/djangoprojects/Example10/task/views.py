from django.shortcuts import render

# Create your views here.
def converter(req):
    if req.method=='POST':
        a=float(req.POST.get('rupee'))
        b=a/85.84
        return render(req,'currencyconversion.html',{'money':b})
    else:
        return render(req,'currencyconversion.html')
    
# def twoconverter(req):
#     if req.method=='POST':
#         a=req.POST.get('rupee')
#         b=req.POST.get('dollar')
#         if a ==req.POST.get('rupee'):
#             c=float(a)/85.54
#             return render(req,'twoconverter.html',{'money':c})
#         elif b==req.POST.get('dollar'):
#             d=float(b)*85.54
#             return render(req,'twoconverter.html',{'dollar':d})
#         else:
#             return render(req,'twoconverter.html',{'msg':"fill any box with number"})
#     else:
#         return render(req,'twoconverter.html')    
    
def twoconverter(req):
    if req.method == 'POST':
        a = req.POST.get('rupee')
        b = req.POST.get('dollar')

        if a==req.POST.get('rupee'):
            a = float(a)
            c = a / 85.54
            return render(req, 'twoconverter.html', {'money':a,'dollar': c})
        elif b == req.POST.get('dollar'):
            b = float(b)
            d = b * 85.54
            return render(req, 'twoconverter.html', {'money': d,'dollar':b})
        else:
            return render(req, 'twoconverter.html', {'msg': "Fill any box with number"})
    else:
        return render(req, 'twoconverter.html')
