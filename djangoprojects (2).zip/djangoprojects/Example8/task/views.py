from django.shortcuts import render

def check(req):
    data={'Empdata':[{'eid':101,'ename':'vishnu','sal':32000.0},{'eid':102,'ename':'Arun','sal':35000.0}]}
    return render(req,'nesteddata.html',data)

# Create your views here.
