from django.shortcuts import render

# Create your views here.
def home(req):
    return render(req,'home.html')

def login(req):
    if req.method=="post":
        pass
        
    else:
        return render(req,'home.html')    
    
def update(req):
    if True:
        pass
    else:
        return render(req,'update.html')
        