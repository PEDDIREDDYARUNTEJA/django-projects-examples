from django.db import models

# Create your models here.
class register(models.Model):
    cid=models.IntegerField(primary_key=True)
    cname=models.CharField(max_length=50)
    gender=models.CharField(max_length=10)
    phonenumber=models.CharField(max_length=14)
    amount=models.DecimalField(max_digits=10,decimal_places=4)
    username=models.CharField(max_length=20)
    password=models.CharField(max_length=20)
    
class Transaction(models.Model):
    cid=models.IntegerField()
    type=models.CharField(max_length=50)
    amount=models.DecimalField(max_digits=10, decimal_places=2)
    date= models.DateField(auto_now=False, auto_now_add=False)    
    