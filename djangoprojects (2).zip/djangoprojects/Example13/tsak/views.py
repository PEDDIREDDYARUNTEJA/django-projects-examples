from django.shortcuts import render
from .models import register,Transaction
# Create your views here.
def home(req):
    return render(req,'home.html')

def login(req):
    if req.method == "POST":
        a = req.POST.get('uname')
        b = req.POST.get('password')
        try:
            res = register.objects.get(username=a,password=b)
            return render(req, 'welcome.html')
        except:
            return render(req, 'login.html', {'message': 'ENTER CORRECT USERNAME AND PASSWORD'})        
    else:
        return render(req, 'login.html')


def Register(req):
    if req.method=="POST":
        cid=req.POST.get('cid')
        cname=req.POST.get('cname')
        gender=req.POST.get('gender')
        pho=req.POST.get('pno')
        amount=req.POST.get('amount')
        username=req.POST.get('uname')
        password=req.POST.get('password')
        res=register(cid=cid,cname=cname,gender=gender,phonenumber=pho,amount=amount,username=username,password=password)
        res.save()
        return render(req,'login.html',{'msg':'login here'})
    else:
        return render(req,'Register.html')

def widthdraw(req):
    if req.method=='POST':
        a=req.POST.get('cid')
        b=req.POST.get('type')
        c=req.POST.get('amount')
        d=req.POST.get('date')
        res=register.objects.get(cid=a)
        k=res.amount-int(c)
        res.amount=k
        res.save()
        m=Transaction(cid=a,type=b,amount=c,date=d)
        m.save()
        return render(req,'widthdraw.html',{'message':'amount widthdraw completed'})
    else:    
        return render (req,'widthdraw.html')

def deposit(req):
    if req.method=='POST':
        a=req.POST.get('cid')
        b=req.POST.get('type')
        c=req.POST.get('amount')
        d=req.POST.get('date')
        res=register.objects.get(cid=a)
        k=res.amount+int(c)
        res.amount=k
        res.save()
        m=Transaction(cid=a,type=b,amount=c,date=d)
        m.save()
        return render(req,'deposit.html',{'message':'amount deposit completed'})
    else:
        return render(req,'deposit.html')
 
 
 
def welcome(req):
    return render(req,'welcome.html')
 
 
 
            
def mini(req):
    if req.method=='POST':
        a=req.POST.get('cid')
        try:
            res=Transaction.objects.filter(cid=a)
            d={'element':res}
            return render(req,'mini.html',d)
        except:
            return render(req,'mini.html',{'message':'Enter correct cid'})
    else:
        return render(req,'mini.html')