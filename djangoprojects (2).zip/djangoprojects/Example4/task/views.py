from django.shortcuts import render

# Create your views here.
def check(req):
    if req.method=='POST':
        a=int(req.POST.get('number'))
        if a==0:
            res='cheppalem'
        elif a%2==0:
            res='EVEN'
        else:
            res='ODD'
        return render(req,'checkno.html',{'result':res}) 
     
    
    else:   
            return render(req,'checkno.html')
def show(req):
    return render(req,'checkno.html')        
        
          