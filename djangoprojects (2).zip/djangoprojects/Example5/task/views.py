from django.shortcuts import render
def bigger(req):
    d={'a':5,'b':10,'c':8}
    return render(req,'biggest.html',d)
# Create your views here.
