from django.shortcuts import render
def Ticket(req):
    d={'age':66}
    return render(req,'ticket.html',d)

# Create your views here.
