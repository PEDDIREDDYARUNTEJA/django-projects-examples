from django.shortcuts import render
from .models import emp

# Create your views here.
def data(req):
    if req.method=='POST':
        a=req.POST.get('eid')
        b=req.POST.get('ename')
        c=req.POST.get('salary')
        d=req.POST.get('dno')
        e1=emp(eid=a,ename=b,salary=c,dno=d)
        e1.save()
        return render(req,'Register.html',{'msg':'REGISTRATION SUCCESSFUL'})
    else:
        return render(req,'Register.html')
    
def search(req):
    if req.method=='POST':
        a=int(req.POST.get('eid'))
        res=emp.objects.get(eid=a)
        d1={'Employee':res}
        return render(req,'search.html',d1)
    else:
        return render(req,'search.html')