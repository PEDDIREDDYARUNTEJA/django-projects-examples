from django.shortcuts import render


def home(req):
    return render(req, 'home.html')


def output(req):
    a = req.GET.get('evenorodd')
    if int(a) % 2 == 0:
        k = 'even number'
    else:
        k = 'odd number'

    b = req.GET.get('eligibility')
    if int(b) >= 18:
        j = 'eligible for vote'
    else:
        j = 'not eligible for vote'
    c = req.GET.get('primeornot')
    count = 0
    for i in range(1, int(c) + 1):
        if int(c) % i == 0:
            count = count + 1
    if count == 2:
        m = 'prime number'
    else:
        m = 'not prime'
    d = {'evenorodd': k, 'eligibleornot': j, 'primeornot': m, 'a': a, 'b': b, 'c': c}
    return render(req, 'output.html', d)
# Create your views here.


# Create your views here.
