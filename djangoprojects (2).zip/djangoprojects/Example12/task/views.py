from django.shortcuts import render
from .models import student
# Create your views here.
def insert(req):
    if req.method=="POST":
        a=req.POST.get('sid')
        b=req.POST.get('sname')
        c=req.POST.get('s1marks')
        d=req.POST.get('s2marks')
        e=req.POST.get('s3marks')
        e1=student(sid=a,sname=b,s1marks=c,s2marks=d,s3marks=e)
        e1.save()
        return render(req,'insert.html',{'message':"data inserted"})
    else:
        return render(req,'insert.html')
     
# def search(req):
    if req.method == 'POST':
        a = int(req.POST.get('sid'))
        res = student.objects.filter(sid=a).first()
        if res is None:
            return render(req, 'search.html', {'message': 'INVALID ID'})
        else:
            d = {'element': res}
            return render(req, 'search.html', d)
    else:
        return render(req, 'search.html')
def search(req):
    if req.method == 'POST':
        a = int(req.POST.get('sid'))
        try:
            res = student.objects.get(sid=a)
            d = {'element': res}
        except:
            d = {'message': 'INVALID ID'}
        return render(req, 'search.html', d)
    else:
        return render(req, 'search.html')
    
# #def table(req):
#     if req.method=='POST':
#         a=req.POST.get('sid')
#         try:
#             res=student.objects.get(sid=a)
#             d={'element':res}
#             for i in d.values():
#                 a=i.sid
#                 b=i.sname
#                 c=i.s1marks
#                 d=i.s2marks
#                 e=i.s3marks
#                 total=c+d+e
#                 average=total/3
#                 if average>35:
#                     Result='pass'
#                 else:
#                     Result='Fail'
#             f={'sid':a,'sname':b,'s1':c,'s2':d,'s3':e,'total':total,'average':average,'Result':Result}            
#             return render(req,'table.html',f)
#         except:
#             d = {'message': 'INVALID ID'}
#         return render(req, 'table.html', d)
                
                    
    