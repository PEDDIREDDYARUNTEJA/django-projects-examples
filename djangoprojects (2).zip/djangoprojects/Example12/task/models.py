from django.db import models
# Create your models here.
class student(models.Model):
    sid=models.IntegerField(primary_key=True)
    sname=models.CharField(max_length=25)
    s1marks=models.IntegerField()
    s2marks=models.IntegerField()
    s3marks=models.IntegerField()
    