from django.shortcuts import render

def login(req):
    return render(req, 'login.html')


# def error(req):
#     return render(req,'error.html')
def welcome(req):
    a = req.GET.get('uname')
    b = req.GET.get('pwd')
    if a=='arun' and b=='Arun@1234':
        d = {'uname': a}
        return render(req, 'welcome.html', d)
    else:
        return render(req,'error.html')
