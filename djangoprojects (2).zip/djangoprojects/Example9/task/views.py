from django.shortcuts import render

def check(req):
    if req.method =='POST':
        a=int(req.POST.get('number1'))
        b=int(req.POST.get('number2'))
        sum=a+b
        sub=a-b
        mul=a*b
        division=a/b
        
        
    
# Create your views here.
