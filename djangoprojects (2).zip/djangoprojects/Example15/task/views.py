from django.shortcuts import render
from .models import customer
# Create your views here.
def customers(request):
    if request.method=="POST":
        cid=request.POST.get('cid')
        cname=request.POST.get('cname')
        password=request.POST.get('pwd')
        res=customer(cid=cid,cname=cname,pwd=password)
        res.save()
        return render (request,"customer.html",{'message':"data inserted"})
    else:
        return render (request,"customer.html")

def newpwd(req):
    if req.method=="POST":
        uid=req.POST.get('cid')
        newpwd=req.POST.get('npwd')
        try:
            res=customer.objects.get(cid=uid)
            res.pwd=newpwd
            res.save()
            return render(req,'pwdchange.html',{'message':"Data Saved"})
    
        except:
            return render(req,'pwdchange.html',{'message':"no data found"})
    else:
        return render(req,'pwdchange.html')   
        
def delete(req):
    if req.method=="POST":
        uid=req.POST.get('cid')
        try:
            res=customer.objects.get(cid=uid)
            res.delete()
            return render(req,'delete.html',{'message':"data deleted"})
        except:
            return render(req,'delete.html',{'message':"id not matched"})
    else:
        return render(req,'delete.html')    
        
def login(req):
    if req.method=="POST":
        uname=req.POST.get('cname')
        password=req.POST.get('pwd')
        try:
            res=customer.objects.filter(cname=uname,pwd=password).first()
            if len(res)>0:
                return render(req,'welcome.html')
            else:
              return render(req,'login.html',{'message':"invalid username and password "}) 
            
        except:
            return render(req,'login.html',{'message':"invalid username and password "}) 
    else:
        return render(req,'login.html')
def newpassword(req):
    if req.method=="POST":
        uid=req.POST.get('cid')
        password=req.POST.get('pwd')
        newpwd=req.POST.get('npwd')
        res=customer.objects.filter(cid=uid,pwd=password)
        if res is None:
            return render(req,'pwdchange.html',{'message':"no data found"})
        else:
            res.pwd=newpwd
            res.save()
            return render(req,'pwdchange.html',{'message':"Data Saved"})
    else:
         return render(req,'pwdchange.html')   
        
    

       
           