from django.db import models

# Create your models here.
class customer(models.Model):
    cid=models.IntegerField(primary_key=True)
    cname=models.CharField(max_length=50)
    pwd=models.CharField(max_length=50)