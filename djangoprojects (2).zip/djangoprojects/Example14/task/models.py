from django.db import models

class loan(models.Model):
    loanid=models.IntegerField(primary_key=True)
    loanname=models.CharField(max_length=50)
    roi=models.DecimalField(max_digits=5, decimal_places=2)
    
class empdetails(models.Model):
    eid=models.IntegerField(primary_key=True)
    ename=models.CharField(max_length=50)
    address1=models.CharField(max_length=150)
    address2=models.CharField(max_length=150)
    phno=models.CharField(max_length=14)
    
class customer(models.Model):
    cid=models.IntegerField(primary_key=True)
    cname=models.CharField(max_length=50)
    amount=models.DecimalField(max_digits=50, decimal_places=2)