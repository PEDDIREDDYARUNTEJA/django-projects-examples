from django.shortcuts import render
from .models import loan,customer,empdetails

# Create your views here.
def loan1(req):                       # insert data in the loan table
    if req.method=='POST':
        a=req.POST.get('loanid')
        b=req.POST.get('loanname')
        c=req.POST.get('roi')
        k=loan(loanid=a,loanname=b,roi=c)
        k.save()
        return render(req,'loan.html',{'message':'data Added'})
    else:
        return render(req,'loan.html')
    
def customer1(req):                 # insert data in the customer table
    if req.method=='POST':
        a=req.POST.get('cid')
        b=req.POST.get('cname')
        c=req.POST.get('amount')
        m=customer(cid=a,cname=b,amount=c)
        m.save()
        return render(req,'customer.html',{'message':'data Added'})
    else:
        return render(req,'customer.html')


def delete(req):                     #loan data delete by using loanid
    if  req.method=='POST':
        a=req.POST.get('loanid')
        res=loan.objects.get(loanid=a)
        res.delete()
        return render(req,'loaniddelete.html',{'message':'data deleted'})  
    else:
        return render(req,'loaniddelete.html')
    
def update(req):                     #update loan record using loanid
    if  req.method=='POST':
        a=req.POST.get('loanid')
        b=req.POST.get('roi')
        res=loan.objects.get(loanid=a)
        res.roi=float(b)
        res.save()
        return render(req,'loanupdate.html',{'message':'data updated'})
    else:
        return render(req,'loanupdate.html')
    
def employee(req):                     #data added into employee table
    if req.method=='POST':
        a=req.POST.get('empid')
        b=req.POST.get('ename')
        c=req.POST.get('address1')
        d=req.POST.get('address2')
        e=req.POST.get('phno')
        res=empdetails(eid=a,ename=b,address1=c,address2=d,phno=e)
        res.save()
        return render(req,'empdetails.html',{'message':'data added'})
    else:
        return render(req,'empdetails.html')
def search(req):
    if req.method=='POST':
        a=req.POST.get('loanid')
        res=loan.objects.get(loanid=a)
        b=res.loanname
        c=res.roi
        d={'loanid':a,'loanname':b,'roi':c}
        return render(req,'searchrecord.html',d)
    else:
        return render(req,'searchrecord.html')
    
        
        

        
        
     