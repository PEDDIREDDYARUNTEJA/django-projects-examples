from django.shortcuts import render

def register(req):
    return render(req,'Register.html')
def details(arun):
    a=arun.GET.get('personid')
    b=arun.GET.get('personname')
    c=arun.GET.get('age')
    d=arun.GET.get('gender')
    e=arun.GET.get('city')
    f=arun.GET.getlist('hobbies')
    d={'personid':a,'personname':b,'age':c,'gender':d,'city':e,'hobbies':f}
    return render(arun,'Details.html',d)

# Create your views here.
